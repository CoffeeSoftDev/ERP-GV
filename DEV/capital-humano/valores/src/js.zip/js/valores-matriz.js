class Matrix extends App 
{
    constructor(link, div_modulo) {
        super(link, div_modulo);
    }

    render() {
        this.layout();
        this.filterBar();
        this.ls();
    }

    async getListEvaluated() {
        let data = await useFetch({ url: this._link, data: { opc: "getEvaluated", udn: $("#id_udn").val() } });
        $("#id_evaluated").option_select({ select2: true, father: true, data: data });
    }

    async getListEvaluators() {
        let data = await useFetch({ url: this._link, data: { opc: "getEvaluators" } });
        $("#id_evaluator").option_select({ select2: true, father: true, data: data, placeholder: "Seleccione uno o varios evaluadores" });
    }

    matrixModal(id) {
        bootbox.dialog({
            title: "Nueva Matriz",
            closeButton: true,
            message: `
                <form class="row" id="formMatrix" novalidate>
                    <div class="col-12 mb-2">
                        <label for="id_udn" class="form-label fw-bold">UDN</label>
                        <select class="form-select" id="id_udn" name="id_UDN" onchange="matrix.getListEvaluated()" required></select>
                    </div>
                    <div class="col-12 mb-2">
                        <label for="id_evaluated" class="form-label fw-bold">Evaluado</label>
                        <select class="form-select" id="id_evaluated" name="id_evaluated" required></select>
                    </div>
                    <div class="col-12 mb-3">
                        <label for="id_evaluator" class="form-label fw-bold">Evaluadores</label>
                        <select class="form-select" id="id_evaluator" name="id_evaluator" multiple></select>
                    </div>
                    <div class="col-12 text-center">
                        <button type="submit" class="btn btn-primary col-12 col-sm-6">Guardar</button>
                    </div>
                </form>
                `,
        });

        udn = udn.slice(1);
        $("#id_udn").option_select({ select2: false, father: true, data: udn });
        matrix.getListEvaluated();
        matrix.getListEvaluators();
       
        $("#formMatrix").validation_form({}, function (result) { 
            // Validar que el campo evaluador no este vacio
            if ($("#id_evaluator").val() == null || $("#id_evaluator").val() == "") {
                alert({ icon: "error", text: "Seleccione al menos un evaluador", btn1: true, btn1Text: "Ok" });
                return false;
            }
            //Validar que el array de evaluadores no contenga al evaluado
            if ($("#id_evaluator").val().includes($("#id_evaluated").val())) {
                alert({ icon: "error", text: "El evaluador no puede ser el mismo que el evaluado", btn1: true, btn1Text: "Ok" });
                return false;
            }
            $("#formMatrix button[type='submit']").attr("disabled", "disabled");
            matrix.addMatrix(id);
        });
    }

    addMatrix(id) {
        let datos = {
            opc: "addMatrix",
            id_udn: $("#id_udn").val(),
            id_evaluated: $("#id_evaluated").val(),
            id_evaluator: $("#id_evaluator").val(),
        };

        fn_ajax(datos, ctrl).then((response) => {
            if (response.status == 200) {
                alert({ icon: "success", text: response.message });
                $("#formMatrix button[type='submit']").removeAttr("disabled");
                $("#id_evaluator").val(null).trigger("change");
                matrix.ls();
            } else {
                alert({ icon: "error", text: response.message, btn1: true, btn1Text: "Ok" });
                $("#formMatrix button[type='submit']").removeAttr("disabled");
            }
        });
    }

    async editMatriz(id) {
        let data = await useFetch({ url: this._link, data: { opc: "getMatrix", id: id } });
        let evaluators = await useFetch({ url: this._link, data: { opc: "getEvaluators" } });
       
        bootbox.dialog({
            title: `Editar Matriz de ` + data.matrix[0].nombre,
            closeButton: true,
            message: `
                <form class="row" id="formMatrix" novalidate>
                    <div class="col-12 mb-3">
                        <label for="id_evaluator" class="form-label fw-bold">Evaluadores</label>
                        <select class="form-select" id="id_evaluator" name="id_evaluator" multiple></select>
                    </div>
                    <div class="col-12 text-center">
                        <button type="submit" class="btn btn-primary col-12 col-sm-6">Guardar</button>
                    </div>
                </form>
                `,
        });
        $("#id_evaluator").option_select({ select2: true, father: true, data: evaluators, placeholder: "Seleccione uno o varios evaluadores" });

        let evala = [];

        data.evaluadores.forEach(element => {
            evala.push(element.id_evaluator);  // Extraer el id_evaluator
        });

        $("#id_evaluator").val(evala).trigger("change");

        $("#formMatrix").validation_form({}, function (result) { 
            // Validar que el campo evaluador no este vacio
            if ($("#id_evaluator").val() == null || $("#id_evaluator").val() == "") {
                alert({ icon: "error", text: "Seleccione al menos un evaluador", btn1: true, btn1Text: "Ok" });
                return false;
            }
            //Validar que el array de evaluadores no contenga al evaluado
            if ($("#id_evaluator").val().includes($("#id_evaluated").val())) {
                alert({ icon: "error", text: "El evaluador no puede ser el mismo que el evaluado", btn1: true, btn1Text: "Ok" });
                return false;
            }
            $("#formMatrix button[type='submit']").attr("disabled", "disabled");
            matrix.updateMatrix(id);
        });
    }

    updateMatrix(id) {
        let datos = {
            opc: "editMatrix",
            id_evaluator: $("#id_evaluator").val(),
            id_matrix: id,
        };

        fn_ajax(datos, ctrl).then((response) => {
            if (response.status == 200) {
                alert({ icon: "success", text: response.message });
                $("#formMatrix button[type='submit']").removeAttr("disabled");
                $("#id_evaluator").val(null).trigger("change");
                $(".bootbox").modal("hide"); // Cerrar modal
                matrix.ls();
            } else {
                alert({ icon: "error", text: response.message, btn1: true, btn1Text: "Ok" });
                $("#formMatrix button[type='submit']").removeAttr("disabled");
            }
        });
    }

    cancelMatriz(id) {
        this.swalQuestion({
            opts: {
                title: "¿Cancelar esta matriz?",
                text: "Una vez cancelada, no podrás reutilizarla en evaluaciones.",
            },
            data: {
                opc: "cancelMatrix",
                status: 0,
                idMatrix: id,
            },
            methods: {
                request: (res) => {
                    if (res.status == 200) {
                        alert({
                            icon: "success",
                            text: res.message,
                            timer: 1500,
                        });
                        matrix.ls();
                    } else {
                        alert({
                            icon: "error",
                            text: res.message,
                            timer: 1500,
                        });
                    }
                }
            }
        });
    }
}