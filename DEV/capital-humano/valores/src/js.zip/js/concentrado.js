// class Concentrado extends App {
//     constructor(link, div_modulo) {
//         super(link, div_modulo);
//         this.Evaluador = '';
//     }

// }